import type { Border, TripEventType, TripStatus } from "@/types/trip";

export type PortalEvent = {
  id: string;
  type: TripEventType;
  occurredAt: string;
  fromStatus: TripStatus | null;
  toStatus: TripStatus | null;
  note: string | null;
  createdAt: string;
};

export type PortalShipment = {
  id: string;
  currentStatus: TripStatus;
  currentPosition: string | null;
  border: Border | null;
  tonnage: string | null;
  loadedDate: string | null;
  departureDate: string | null;
  arrivalEstimate: string | null;
  arrivalDate: string | null;
  cargo: {
    code: string;
    description: string | null;
    origin: string;
    destination: string;
  };
  truck: { plateNumber: string };
  driver: { fullName: string };
  createdAt: string;
};

export type PortalShipmentDetail = PortalShipment & {
  trackingToken: string;
  events: PortalEvent[];
};
